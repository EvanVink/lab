module ca.bcit.comp1510f.athree {
    requires org.junit.jupiter.api;

    exports q1;
    exports q2;
    exports q3;
}