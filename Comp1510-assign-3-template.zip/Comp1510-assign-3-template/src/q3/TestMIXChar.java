package q3;

/**
 * This is where you put your description about what this class does. You
 * don't have to write an essay but you should describe exactly what it does.
 * Describing it will help you to understand the programming problem better.
 *
 * @author Your Name goes here
 * @version 1.0
 */
public class TestMIXChar {
    
    //the following are for reference, you may want to move them or copy them 
    //to another class.
    private static final char DELTA = '\u0394';
    
    private static final char SIGMA = '\u03A3';
    
    private static final char PI = '\u03A0';
    
    /**
     * This is the main method (entry point) that gets called by the JVM.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        //replace next line with your code:
        System.out.println("Question three was called and ran sucessfully.");
    }
    
}
